create function WhatDev(g varchar(30)) returns int
BEGIN
	RETURN (SELECT distinct developer FROM games WHERE id = g);    

END;

