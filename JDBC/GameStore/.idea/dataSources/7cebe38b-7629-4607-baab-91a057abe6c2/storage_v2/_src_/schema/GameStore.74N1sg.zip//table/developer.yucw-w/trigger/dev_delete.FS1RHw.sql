create trigger dev_delete
  after DELETE
  on developer
  for each row
BEGIN
	DELETE FROM games WHERE games.developer = OLD.id;
END;

