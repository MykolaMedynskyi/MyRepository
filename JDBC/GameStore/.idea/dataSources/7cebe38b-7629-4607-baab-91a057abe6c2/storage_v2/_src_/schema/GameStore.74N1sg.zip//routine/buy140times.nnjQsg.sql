create procedure buy140times()
BEGIN
     declare x INT;
     SET x = 1;
     WHILE x <= 140 DO
 		INSERT INTO history VALUES 
         ((SELECT id FROM games ORDER BY RAND() LIMIT 1),
          (SELECT id FROM users WHERE access = 'customer' ORDER BY RAND() LIMIT 1), 
           (SELECT now()));
         SET x = x + 1;
    END WHILE;
   END;

