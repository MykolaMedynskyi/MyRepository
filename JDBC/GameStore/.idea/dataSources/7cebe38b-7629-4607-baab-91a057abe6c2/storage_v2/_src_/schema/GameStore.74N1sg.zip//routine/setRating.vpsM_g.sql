create procedure setRating(IN g int)
BEGIN
	DECLARE r DOUBLE;
    SET r = (SELECT (SUM(rating)/(SELECT COUNT(game) FROM ratings WHERE game = g)) AS rating FROM ratings GROUP BY game HAVING game = g);
    UPDATE games SET rating = r WHERE id = g;

END;

