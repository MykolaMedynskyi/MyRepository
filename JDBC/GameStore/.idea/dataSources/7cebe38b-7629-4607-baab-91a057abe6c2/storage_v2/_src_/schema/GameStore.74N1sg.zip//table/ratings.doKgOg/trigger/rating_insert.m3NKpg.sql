create trigger rating_insert
  after INSERT
  on ratings
  for each row
BEGIN
    
	call GameStore.setRating(NEW.game);

    
END;

