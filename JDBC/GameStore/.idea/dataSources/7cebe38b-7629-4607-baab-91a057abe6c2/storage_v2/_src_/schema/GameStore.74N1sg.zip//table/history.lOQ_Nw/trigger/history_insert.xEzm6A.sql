create trigger history_insert
  after INSERT
  on history
  for each row
BEGIN  
call GameStore.checkBestGame(new.game); 
END;

