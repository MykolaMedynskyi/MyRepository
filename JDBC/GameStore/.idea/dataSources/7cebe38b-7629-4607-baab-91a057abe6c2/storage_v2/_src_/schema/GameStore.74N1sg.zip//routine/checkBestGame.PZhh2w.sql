create procedure checkBestGame(IN g int)
BEGIN
	
    DECLARE d INT;
    DECLARE bg INT;
    SET d = (SELECT GameStore.WhatDev(g));
	SET bg = (SELECT GameStore.WhatBestGame(d));
    
    UPDATE developer SET bestGame = bg WHERE id = d;
    
END;

