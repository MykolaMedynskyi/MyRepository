create procedure filling_tags()
BEGIN
     declare x INT;
     SET x = 1;
     WHILE x <= 100 DO
 		UPDATE games SET tags =
         (SELECT group_concat(idtag) FROM (SELECT idtag FROM tag ORDER BY rand() LIMIT 1,3) AS g) WHERE games.id = x;
         SET x = x + 1;
    END WHILE;
   END;

