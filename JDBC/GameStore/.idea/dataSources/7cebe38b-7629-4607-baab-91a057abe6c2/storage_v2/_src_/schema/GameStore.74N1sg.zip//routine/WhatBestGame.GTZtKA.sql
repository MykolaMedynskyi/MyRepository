create function WhatBestGame(d int) returns int
BEGIN
	RETURN (SELECT distinct game FROM (
SELECT game, COUNT(game) AS t
	FROM history INNER JOIN games ON history.game = games.id
	WHERE games.developer = d
	GROUP BY game
) AS b WHERE b.t = (SELECT MAX(a.t) FROM
(SELECT game, COUNT(game) AS t
	FROM history INNER JOIN games ON history.game = games.id
	WHERE games.developer = d
	GROUP BY game) AS a ) LIMIT 1);    

END;

